# Ngày 1 — Bài Tập & Phản Ánh
## Nền Tảng LLM API | Phiếu Thực Hành

**Thời lượng:** 1:30 giờ  
**Cấu trúc:** Lập trình cốt lõi (60 phút) → Bài tập mở rộng (30 phút)

---

## Phần 1 — Lập Trình Cốt Lõi (0:00–1:00)

Chạy các ví dụ trong Google Colab tại: https://colab.research.google.com/drive/172zCiXpLr1FEXMRCAbmZoqTrKiSkUERm?usp=sharing

Triển khai tất cả TODO trong `template.py`. Chạy `pytest tests/` để kiểm tra tiến độ.

**Điểm kiểm tra:** Sau khi hoàn thành 4 nhiệm vụ, chạy:
```bash
python template.py
```
Bạn sẽ thấy output so sánh phản hồi của GPT-4o và GPT-4o-mini.

---

## Phần 2 — Bài Tập Mở Rộng (1:00–1:30)

### Bài tập 2.1 — Độ Nhạy Của Temperature
Gọi `call_openai` với các giá trị temperature 0.0, 0.5, 1.0 và 1.5 sử dụng prompt **"Hãy kể cho tôi một sự thật thú vị về Việt Nam."**

**Bạn nhận thấy quy luật gì qua bốn phản hồi?** (2–3 câu)
> *Câu trả lời của bạn*

**Bạn sẽ đặt temperature bao nhiêu cho chatbot hỗ trợ khách hàng, và tại sao?**
> *Câu trả lời của bạn*
 temperature càng cao thì phản hồi càng đa dạng và sáng tạo, nhưng cũng dễ mất tính ổn định và chính xác.


---

### Bài tập 2.2 — Đánh Đổi Chi Phí
Xem xét kịch bản: 10.000 người dùng hoạt động mỗi ngày, mỗi người thực hiện 3 lần gọi API, mỗi lần trung bình ~350 token.

**Ước tính xem GPT-4o đắt hơn GPT-4o-mini bao nhiêu lần cho workload này:**
> Với kịch bản 10.000 người dùng mỗi ngày, mỗi người 3 lần gọi API, trung bình 350 token/lần:
• 	Tổng số token/ngày = 10.000 × 3 × 350 = 10,5 triệu token.
• 	Nếu giả sử chi phí GPT‑4o ≈ 0,005 USD/1.000 token và GPT‑4o‑mini ≈ 0,0015 USD/1.000 token:
• 	GPT‑4o: 10,5 triệu ÷ 1.000 × 0,005 ≈ 52,5 USD/ngày.
• 	GPT‑4o‑mini: 10,5 triệu ÷ 1.000 × 0,0015 ≈ 15,75 USD/ngày.
→ GPT‑4o đắt hơn khoảng 3,3 lần so với GPT‑4o‑mini cho workload này.

**Mô tả một trường hợp mà chi phí cao hơn của GPT-4o là xứng đáng, và một trường hợp GPT-4o-mini là lựa chọn tốt hơn:**
> Trường hợp GPT‑4o xứng đáng: Khi cần độ chính xác cao, diễn đạt mạch lạc và xử lý ngữ cảnh phức tạp, ví dụ chatbot hỗ trợ khách hàng trong lĩnh vực tài chính hoặc y tế, nơi sai sót có thể gây hậu quả lớn.
Trường hợp GPT‑4o‑mini phù hợp hơn: Khi chỉ cần phản hồi nhanh, chi phí thấp, và nội dung đơn giản như gợi ý ý tưởng, tóm tắt ngắn, hoặc trợ lý học tập cho sinh viên, nơi tốc độ và tiết kiệm quan trọng hơn độ tinh vi.


---

### Bài tập 2.3 — Trải Nghiệm Người Dùng với Streaming
**Streaming quan trọng nhất trong trường hợp nào, và khi nào thì non-streaming lại phù hợp hơn?** (1 đoạn văn)
> Streaming quan trọng nhất trong những tình huống mà tốc độ phản hồi và cảm giác “tương tác trực tiếp” là yếu tố cốt lõi. ví dụ chatbot hỗ trợ khách hàng, trợ lý học tập, hoặc khi người dùng đặt câu hỏi dài và muốn thấy câu trả lời xuất hiện dần để nắm bắt ngay từng ý. Nó giúp giảm cảm giác chờ đợi và tạo trải nghiệm tự nhiên hơn.
Ngược lại, non‑streaming phù hợp hơn khi người dùng cần câu trả lời hoàn chỉnh, chính xác và có cấu trúc rõ ràng ngay lập tức, chẳng hạn khi lấy báo cáo, tóm tắt dữ liệu, hoặc nội dung cần sao chép nguyên văn. Trong những trường hợp này, việc nhận toàn bộ kết quả một lần sẽ tiện lợi và dễ xử lý hơn.



## Danh Sách Kiểm Tra Nộp Bài
- [ ] Tất cả tests pass: `pytest tests/ -v`
- [ ] `call_openai` đã triển khai và kiểm thử
- [ ] `call_openai_mini` đã triển khai và kiểm thử
- [ ] `compare_models` đã triển khai và kiểm thử
- [ ] `streaming_chatbot` đã triển khai và kiểm thử
- [ ] `retry_with_backoff` đã triển khai và kiểm thử
- [ ] `batch_compare` đã triển khai và kiểm thử
- [ ] `format_comparison_table` đã triển khai và kiểm thử
- [ ] `exercises.md` đã điền đầy đủ
- [ ] Sao chép bài làm vào folder `solution` và đặt tên theo quy định 
