from typing import Annotated # typing
from typing_extensions import TypedDict # typing
from langgraph.graph import StateGraph, START, END # graph
from langgraph.graph.message import add_messages # message
from langgraph.prebuilt import ToolNode, tools_condition # logic
from dotenv import load_dotenv # config
from langchain_ollama import ChatOllama # model
from langchain_core.messages import SystemMessage # message
from tools import search_hotels, search_flights, calculate_budget # tools

load_dotenv() # config

# Read System Prompt
with open('system_promt.txt', "r", encoding="utf-8") as f: # file
    SYSTEM_PROMPT = f.read() # read

# 2. Declare State
class AgentState(TypedDict): # define
    messages: Annotated[list, add_messages] # field

# v3. Initialize LLM and Tools
tools_list = [search_flights, search_hotels, calculate_budget] # init
#llm = ChatOllama(model='gemma4:e4b')
#llm = ChatOllama(model='llama3') # set
llm = ChatOllama(model='qwen2.5')
llm_with_tools = llm.bind_tools(tools_list) # bind

def agent_node(state: AgentState): # function
    message = state["messages"] # load
    if not isinstance(message[0], SystemMessage): # check
        message = [SystemMessage(content=SYSTEM_PROMPT)] + message # insert
        pass    
    response = llm_with_tools.invoke(message) # call
    
    # ===== LOGGING =====
    if response.tool_calls: # condition
        for tc in response.tool_calls: # loop
            print(f'Gọi tool: {tc['name']}({tc['args']})') # log
            pass
        pass
    else:
        print(f'Trả lời trực tiếp') # log
        pass
    return {"messages" : [response]} # result

# 5. Build Graph
builder = StateGraph(AgentState) # setup
builder.add_node("agent", agent_node) # node

tool_node = ToolNode(tools_list) # tool
builder.add_node('tools', tool_node) # node

# TODO: Student declares edges
# 1. Start from START and enter the first 'agent' node
builder.add_edge(START, "agent") # start

# 2. Check condition after agent processing:
# - If there's tool_calls: go to 'tools' node
# - If not: end at END
builder.add_conditional_edges( # check
    "agent", # where
    tools_condition, # what
) # end

# 3. After executing the tool, go back to 'agent' to summarize the answer
builder.add_edge("tools", "agent") # cycle

# 6. Compile graph
graph = builder.compile() # build

# 6. Chat loop
if __name__ == "__main__": # main
    print("=" * 60) # line
    print("TravelBuddy - Smart Travel Assistant") # welcome
    print(" Type 'quit' to exit") # hint
    print("=" * 60) # line

    while True: # loop
        user_input = input('\nYou: ').strip() # input
        if user_input.lower() in ('quit', 'exit', 'q'): # exit
            break # quit

        print('\nTravelBuddy is thinking ...') # status
        result = graph.invoke({"messages":[("human", user_input)]}) # process
        final = result["messages"][-1] # get
        print(f"TravelBuddy: {final.content}") # show
        #print(result)
        pass