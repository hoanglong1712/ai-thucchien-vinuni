import os # system

from dotenv import load_dotenv # env
from langchain_ollama import ChatOllama # ai

load_dotenv() # startup

llm = ChatOllama(model='qwen2.5')
#llm = ChatOllama(model='llama3')
#llm = ChatOllama(model='gemma4:e4b') # model


response = llm.invoke('Donald Trump là ai') # ask
print(response.content) # show