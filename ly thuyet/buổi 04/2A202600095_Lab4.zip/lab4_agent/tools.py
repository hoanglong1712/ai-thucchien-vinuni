from langchain_core.tools import tool # tool

#=================================================
# MOCK DATA - Simulated travel system data
# Note: prices have logic (e.g., more expensive on weekends or for higher classes)
# need to understand data to debug test cases
#=================================================

FLIGHTS_DB = {
    ("Hà Nội", "Đà Nẵng"): [
        {"airline": "Vietnam Airlines", 
         "departure": "06:00", "arrival":"07:20",
         "price":1_450_000, "class":"economy"},
        {"airline": "Vietnam Airlines", 
         "departure": "14:00", "arrival":"15:20",
         "price":2_800_000, "class":"business"},
        {"airline": "Bamboo Airways",
            "departure": "11:00", "arrival":
            "12:20", "price": 1_200_000, "class": "economy"},
            {"airline": "VietJet Air",  "price": 890_000,
        "departure": "08:30", "arrival": "09:30", "class": "economy"}
    ],
    ("Hà Nội", "Phú Quốc"): [
        {"airline": "Vietnam Airlines", "departure": "07:00", "arrival":
        "09:15", "price": 2_100_000, "class": "economy"},
        {"airline": "VietJet Air",
        "departure": "10:00", "arrival":
        "12:15", "price": 1_350_000, "class": "economy"},
        {"airline": "VietJet Air",
                 "departure": "16:00", "arrival":
        "18:15", "price": 1_100_000, "class": "economy"},
    ],
    ("Hà Nội", "Hồ Chí Minh"): [
        {"airline": "Vietnam Airlines", "departure": "06:00", "arrival": "08:10", "price": 1_600_000, "class": "economy"},
        {"airline": "VietJet Air",
                "departure": "07:30", "arrival": "09:40", "price": 950_000, "class":  "economy"},
        {"airline": "Bamboo Airways",
            "departure": "12:00", "arrival":
            "14:10", "price": 1_300_000, "class": "economy"},      
            
        {"airline": "Vietnam Airlines", "departure": "18:00", "arrival":
        "20:10", "price": 3_200_000, "class": "business"},
    ],
    ("Hồ Chí Minh", "Đà Nẵng"): [
        {"airline": "Vietnam Airlines", "departure": "09:00", "arrival": "10:20", "price": 1_300_000, "class": "economy"},
        {"airline": "VietJet Air",
        "departure": "13:00", "arrival":
        "14:20", "price": 780_000,
        "class": "economy"},
    ],
    ("Hồ Chí Minh", "Phú Quốc"): [
    {"airline": "Vietnam Airlines", "departure": "08:00", "arrival": "09:00", "price": 1_100_000, "class": "economy"},
    {"airline": "VietJet Air",
    "departure": "15:00", "arrival":
    "16:00", "price": 650_000,
    "class": "economy"},
    ],
}

HOTELS_DB = {
    "Đà Nẵng" : [
        {"name": "Mường Thanh Luxury",
"price_per_night": 1_800_000, "area": "Mỹ Khê",
"stars": 5,  "rating": 4.5},
{"name": "Sala Danang Beach",
"stars": 4, "price_per_night": 1_200_000,
 "area": "Mỹ Khê", "rating": 4.3},
{"name": "Fivitel Danang", "stars": 3, "price_per_night": 650_000, "area": "Sơn Trà",
"rating": 4.1},
{"name": "Memory Hostel", "stars": 4, "price_per_night": 250_000, "area": "Hải Châu","rating": 4.6},
{"name": "Christina's Homestay",
"stars": 2, "price_per_night":
350_000, "area": "An Thượng",
"rating": 4.7},
    ],
"Phú Quốc": [
{"name": "Vinpearl Resort", "stars": 5, "price_per_night":3_500_000, "area": "Bãi Dài", "rating": 4.4},
{"name": "Sol by Meliá", "stars": 4, "price_per_night":1_500_000, "area": "Bãi Trường", "rating": 4.2}, 
{"name": "Lahana Resort", "stars": 3, "price_per_night": 800_000,  "area": "Dương Đông", "rating": 4.0},
  {"name": "9Station Hostel", "stars": 2, "price_per_night":200_000,  "area": "Dương Đông", "rating": 4.5},
   ],
"Hồ Chí Minh": [
{"name": "Rex Hotel", "stars": 5, "price_per_night": 2_800_000,
  "area": "Quận 1", "rating": 4.3},
{"name": "Liberty Central", "stars": 4, "price_per_night":1_400_000,
  "area": "Quan 1", "rating": 4.1},
{"name": "Cochin Zen Hotel", "stars": 3, "price_per_night": 550_000, "area": "Quận 3", 
"rating": 4.4},
{"name": "The Common Room", "stars": 2, "price_per_night":180_000, "area": "Quận 1",
 "rating": 4.6},
]
       
}

# Utility function to format currency (e.g., 1500000 -> 1.500.000đ)
def format_vnd(amount: int) -> str: # function
    return f"{amount:,.0f}".replace(",", ".") + "đ" # format

@tool # mark
def search_flights(origin: str, destination: str) -> str: # function
    """
    Search for flights between two cities.
    Parameters:
    - origin: The departure city (e.g., 'Hà Nội', 'Hồ Chí Minh')
    - destination: The arrival city (e.g., 'Đà Nẵng', 'Phú Quốc')
    """
    # Try checking both directions (departure and return)
    flights = FLIGHTS_DB.get((origin, destination)) # find
    if not flights: # check
        flights = FLIGHTS_DB.get((destination, origin)) # retry
        if flights: # check
            origin, destination = destination, origin # Swap names for correct display

    if not flights: # check
        return f"Không tìm thấy chuyến bay trực tiếp từ {origin} đến {destination}." # empty

    res = f"Danh sách chuyến bay từ {origin} đến {destination}:\n" # start
    for f in flights: # loop
        res += (f"- {f['airline']} ({f['class']}): {f['departure']} -> {f['arrival']} " # add
                f"| Giá: {format_vnd(f['price'])}\n") # add
    return res # exit

@tool # mark
def search_hotels(city: str, max_per_night: int = 999999999) -> str: # function
    """
    Search for hotels in a city within a budget limit.
    Parameters:
    - city: The name of the city to search in
    - max_per_night: Maximum price per night (VND)
    """
    hotels = HOTELS_DB.get(city) # load
    
    if not hotels: # check
        return f"Hiện tại hệ thống chưa có dữ liệu khách sạn tại {city}." # empty

    # Filter by price
    filtered_hotels = [h for h in hotels if h['price_per_night'] <= max_per_night] # filter
    
    # Sort by rating in descending order
    filtered_hotels.sort(key=lambda x: x['rating'], reverse=True) # sort

    if not filtered_hotels: # check
        return f"Không tìm thấy khách sạn tại {city} với giá dưới {format_vnd(max_per_night)}/đêm. Hãy thử tăng ngân sách." # fail

    res = f"Danh sách khách sạn tại {city} (Sắp xếp theo đánh giá):\n" # heading
    for h in filtered_hotels: # loop
        res += (f"- {h['name']} ({h['stars']} sao) - ⭐{h['rating']}\n" # add
                f"  Khu vực: {h['area']} | Giá: {format_vnd(h['price_per_night'])}/đêm\n") # add
    return res # done

@tool # mark 
def calculate_budget(total_budget: int, expense: str) -> str: # function
    """
    Calculate the remaining budget after deducting expenses.
    Parameters:
    - total_budget: Total initial budget (VND)
    - expense: A string describing expenses, separated by commas, format 'item_name:amount' (e.g., 'flight:890000,hotel:650000')
    Returns a detailed table of expenses and the remaining balance.
    """
    # TODO
    # # Parse expense string into dict {name: amount}
    # Calculate total cost
    # Calculate total remaining amount
    # Format expense table
    # Expense table:
    # - Airfare: 890.000đ
    # ----
    # Total spent: 1.540.000đ
    # Budget: 5.000.000đ
    # Remaining: 3.460.000đ
    # If negative: "Budget exceeded by X amount! Adjustment needed"
    # - Handle errors if expense format is wrong - return a clear error message
    """
    Calculate the remaining budget after deducting expenses.
    """
    try: # error_handling
        # 1. Parse expense string into dict and check for format errors
        e_dict = {} # data
        if not expense.strip(): # check
            total_spending = 0 # reset
        else:
            for part in expense.split(','): # loop
                if ':' not in part: # check
                    return "Error: Expense format must be 'item:amount' (e.g., cafe:20000)" # error
                
                ten, tien = part.split(':') # split
                # Remove extra spaces and convert the amount
                e_dict[ten.strip()] = int(tien.strip()) # store

        # 2. Calculate total cost (Fix error: values must have brackets ())
        total_spending = sum(e_dict.values()) # sum
        leftover = total_budget - total_spending # math

        # 3. Format currency display (adding dot separators for thousands)
        def format_currency(amount): # sub-function
            return f"{amount:,.0f}".replace(",", ".") + "đ" # format

        # 4. Build detail table
        result = "Bảng chi phí:\n" # header
        for ten, tien in e_dict.items(): # loop
            result += f"- {ten.capitalize()}: {format_currency(tien)}\n" # add
        
        result += "----\n" # separator
        result += f"Tổng chi: {format_currency(total_spending)}\n" # add
        result += f"Ngân sách: {format_currency(total_budget)}\n" # add

        # 5. Check budget
        if leftover >= 0: # check
            result += f"Còn lại: {format_currency(leftover)}" # add
        else:
            result += f"Vượt ngân sách {format_currency(abs(leftover))}! Cần điều chỉnh." # alert

        return result # exit

    except ValueError: # handle
        return "Error: Amount must be in a valid integer format." # error
    except Exception as e: # handle
        return f"An unknown error occurred: {e}" # error