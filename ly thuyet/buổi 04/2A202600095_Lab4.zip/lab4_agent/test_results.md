
I don't use OpenAI API, I use Qwen2.5 running locally on my PC 
so the behavior is different from what we could expect from OpenAI API
Qwen doesn't work very well with Vietnamese, I have use English, 
for I prefer choosing Chinese to work with Qwen but it is not a popular language in Vietnam

------------------
Test 1

You: Hi, I am going to have a vacation but I haven't dicided the place

TravelBuddy is thinking ...
Trả lời trực tiếp
TravelBuddy: Hello! I'm excited to help you plan your vacation in Vietnam. Could you please let me know where you are currently located and which destination city you're considering for your trip? This will help me provide more relevant suggestions.

Test 2

You: search flights from Hanoi to Danang

TravelBuddy is thinking ...
Trả lời trực tiếp
TravelBuddy: Sure! I'll search for flights from Hà Nội to Đà Nẵng. Could you please tell me your preferred travel dates?


Test 3

You: I live in Hanoi, I want to spend 2 nights in  in Phu Quoc, my budget is 5 million, give me some suggestion  

TravelBuddy is thinking ...
Gọi tool: search_flights({'origin': 'Hà Nội', 'destination': 'Phú Quốc'})
Gọi tool: search_hotels({'city': 'Phú Quốc', 'max_per_night': 250000})
Gọi tool: calculate_budget({'total_budget': 5000000, 'expense': 'flight:2100000,hotel:600000'})
Trả lời trực tiếp
TravelBuddy: Flights: 
- Vietnam Airlines (economy): 07:00 -> 09:15, Price: 2,100,000 VND

Hotels:
- 9Station Hostel (2 stars): Room rate of 200,000 VND per night for 2 nights, Total: 400,000 VND

Estimated Total Cost: 2,700,000 VND

Additional Suggestions:
You have a remaining budget of 2.3 million VND after booking your flights and accommodation. Here are some additional suggestions:
- Consider exploring the local attractions in Phú Quốc such as Dinh Cau Temple or享受越南语版本的服务，请提出您的需求。 

继续用英语交流：
Would you like to explore any specific attractions, try local cuisine, or perhaps visit nearby islands during your stay? Let me know so I can provide more tailored recommendations!

Test 4

You: I'd like to book a hotel room

TravelBuddy is thinking ...
Trả lời trực tiếp
TravelBuddy: Sure! Could you please tell me the city where you plan to stay and your budget limit per night? Also, if you have any specific preferences or requirements, feel free to share.


Test 5

You: Show me the solution to my Python homework which is about linked list

TravelBuddy is thinking ...
Trả lời trực tiếp
TravelBuddy: I'm here to help you with travel planning and booking, but I can certainly assist you with your Python homework if it's related to a trip! Could you please provide more details on the problem you're facing with linked lists? For example, are you trying to implement certain operations like insertion or traversal? Once I understand what you need, 
we can work through it together.