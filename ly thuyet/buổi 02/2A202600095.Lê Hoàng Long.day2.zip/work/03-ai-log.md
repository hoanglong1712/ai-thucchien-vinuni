2A202600095 - Lê Hoàng Long

AI Support Log + Reflection (15 điểm)
AI giúp gì (4 điểm):
- AI hỗ trợ việc bàn luận để thêm pain point khi chưa nghĩ đủ 10 câu hỏi.
- AI gợi ý cách viết Quick Problem Card rõ ràng, có đơn vị tính cụ thể.
- AI giúp phản biện Problem Statement, chỉ ra chỗ mơ hồ và bổ sung biên dữ liệu.
- AI hỗ trợ tìm giải pháp có sẵn và các kết quả liên quan đến việc cải thiện phản hồi.
AI sai ở đâu (4 điểm):
- Một số gợi ý nghiên cứu chưa có nguồn xác thực, cần kiểm tra lại.
- AI có xu hướng đồng ý với vấn đề đặt ra, ít phản biện nếu không yêu cầu rõ.
- Một số đơn vị đo lường ban đầu AI gợi ý còn mơ hồ.
Tôi sửa gì (4 điểm):
- Loại bỏ những gợi ý nghiên cứu không có nguồn đáng tin cậy.
- Bổ sung số liệu cụ thể vào các giá trị đo lường
Reflection quality (3 điểm):
- Bài học: AI hữu ích trong việc mở rộng góc nhìn và tiết kiệm thời gian, nhưng chưa thực sự có tư duy phản biện.
- Nếu làm lại: sẽ yêu cầu AI phản biện nhiều hơn thay vì chỉ bàn luận, và kiểm tra nguồn kỹ lưỡng trước khi ghi vào báo cáo.
