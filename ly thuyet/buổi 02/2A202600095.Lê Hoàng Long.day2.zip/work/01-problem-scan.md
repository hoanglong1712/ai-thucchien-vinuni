2A202600095 - Lê Hoàng Long

# Lab 2 — AI Opportunity Discovery Sprint (v2)
Context: Sinh viên gặp khó khăn khi viết báo cáo cuối kỳ do lượng tài liệu phải đọc quá lớn và nhiều chủ đề cần liên kết để có kết luận cuối cùng.

Phase 1 - SCAN: 

| Lens | Bài toán |
|------|---------|
| **Lặp lại** |  "Sinh viên phải đọc lại nhiều lần cùng một tài liệu để tìm thông tin liên quan, gây mất thời gian." |
| **Tốn thời gian** | "Việc tổng hợp ý chính từ hàng chục tài liệu mất hàng giờ, khiến tiến độ viết báo cáo bị chậm." |
| **AI có thể tốt hơn** |"Công cụ tìm kiếm trong thư viện số chỉ trả về kết quả thô, không gợi ý mối liên hệ giữa các chủ đề." |
| **Pain từ người khác** | "Nhiều sinh viên phàn nàn rằng khi viết báo cáo nhóm, mỗi người chọn tài liệu khác nhau nên khó thống nhất nội dung." |
| **Tốn thời gian** | "Việc kiểm tra trùng lặp ý tưởng hoặc nội dung giữa các tài liệu rất mất công, dễ bỏ sót." |
| **AI có thể tốt hơn** |"Công cụ hiện tại không hỗ trợ tự động tạo sơ đồ liên kết giữa các chủ đề, khiến sinh viên khó hình dung mối quan hệ." |
| **Pain từ người khác** | "Sinh viên thường bị giảng viên nhận xét rằng báo cáo thiếu logic vì không kết nối được các luận điểm từ nhiều nguồn." |
| **Tốn thời gian** | "Quá trình tìm số liệu cụ thể (ví dụ: thống kê, dữ liệu định lượng) trong tài liệu dài rất chậm." |
| **AI có thể tốt hơn** |"Công cụ hỗ trợ viết hiện tại chỉ gợi ý câu văn, chưa giúp phân tích và đối chiếu nhiều tài liệu để rút ra kết luận." |

Phase 2 - QUICK-ASSESS: 3 Quick problem cards

┌─────────────────────────────────────────────┐
│ QUICK PROBLEM CARD #1                       │
│                                             │
│ Bài toán (1 câu): Khó tổng hợp ý chính từ   │
│ hàng chục tài liệu để viết báo cáo.         │
│                                             │
│ Ai đang đau? Sinh viên năm cuối             │
│                                             │
│ Workflow hiện tại (3-5 bước):               │
│   1. Tìm tài liệu → 2. Đọc chi tiết →       │
│   3. Ghi chú thủ công → 4. Tổng hợp ý →     │
│   5. Viết báo cáo                           │
│                                             │
│ Bước nào tốn nhất? Tổng hợp ý (⏱ 180 min)   │
│                                             │
│ AI có thể giúp ở bước nào? Bước 3 & 4       │
│                                             │
│ Đo thành công bằng gì? Giảm thời gian tổng  │
│ hợp từ 180 min → dưới 60 min                │
│                                             │
│ Quick gut: □ No AI  □ Rule  x LLM  □ Agent  │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│ QUICK PROBLEM CARD #2                       │
│                                             │
│ Bài toán (1 câu): Khó kết nối các chủ đề    │
│ từ nhiều nguồn để tạo luận điểm logic.      │
│                                             │
│ Ai đang đau? Sinh viên viết báo cáo nhóm    │
│                                             │
│ Workflow hiện tại (3-5 bước):               │
│   1. Mỗi người chọn tài liệu → 2. Đọc riêng │
│   → 3. Viết phần mình → 4. Ghép báo cáo     │
│   → 5. Chỉnh sửa logic                      │
│                                             │
│ Bước nào tốn nhất? Ghép báo cáo (⏱ 120 min) │
│                                             │
│ AI có thể giúp ở bước nào? Bước 4 & 5       │
│                                             │
│ Đo thành công bằng gì? Giảm số lần chỉnh    │
│ sửa từ 5 vòng → còn 3 vòng                  │
│                                             │
│ Quick gut: □ No AI  □ Rule  x LLM  □ Agent  │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│ QUICK PROBLEM CARD #3                       │
│                                             │
│ Bài toán (1 câu): Khó tìm số liệu cụ thể    │
│ trong tài liệu dài để minh chứng luận điểm. │
│                                             │
│ Ai đang đau? Sinh viên nghiên cứu           │
│                                             │
│ Workflow hiện tại (3-5 bước):               │
│   1. Xác định chủ đề → 2. Mở tài liệu dài   │
│   → 3. Skim đọc → 4. Tìm số liệu →          │
│   5. Ghi chú và trích dẫn                   │
│                                             │
│ Bước nào tốn nhất? Tìm số liệu (90 min)     │
│                                             │
│ AI có thể giúp ở bước nào? Bước 3 & 4       │
│                                             │
│ Đo thành công bằng gì? Giảm thời gian tìm   │
│ số liệu từ 90 min → dưới 30 min             │
│                                             │
│ Quick gut: □ No AI  □ Rule  x LLM  □ Agent │
└─────────────────────────────────────────────┘


-----------------------------------------------------
│ Bài toán (1 câu): Khó tổng hợp ý chính từ hàng chục tài liệu để viết báo cáo. 
 -> Pain point quá phổ biến, có thể giải quyết bằng kỹ năng đọc và ghi chú, chưa chắc cần AI.

Bài toán (1 câu): Khó kết nối các chủ đề từ nhiều nguồn để tạo luận điểm logic.
-> Workflow nhóm phức tạp nhưng vấn đề chính là phối hợp, có thể xử lý bằng rule hoặc quy trình rõ ràng.

Bài toán (1 câu): Khó tìm số liệu cụ thể trong tài liệu dài để minh chứng luận điểm.
 -> Bài toán chỉ xoay quanh việc tìm số liệu, có thể giải quyết bằng công cụ tìm kiếm nâng cao, chưa đủ để lựa chọn AI.

