# Phase 4 — DEEP-DIVE

## 4.1 — Current-State Workflow

```text
┌─────────────┐     ┌─────────────┐     ┌──────────────┐     ┌──────────────────┐
│ Bước 1      │     │ Bước 2      │     │ Bước 3       │     │ Bước 4           │
│ Tìm job từ  │     │ Lọc job     │     │ Đọc JD       │     │ So sánh với CV   │
│ nhiều nguồn │ ──→ │ (level,     │ ──→ │ (10–20 job)  │ ──→ │ (skill, exp)     │
│             │     │ tech stack) │     │              │     │                  │
│ Ai: Tôi     │     │ Ai: Tôi     │     │ Ai: Tôi      │     │ Ai: Tôi          │
│ ⏱ 15 min    │     │ ⏱ 10 min   │     │ ⏱ 30 min 🔴  │     │ ⏱ 20 min 🔴      │
│ In: Job raw │     │ In: list    │     │ In: JD text  │     │ In: JD + CV      │
│ Out: list   │     │ Out: filtered│    │ Out: hiểu JD │     │ Out: đánh giá    │
└─────────────┘     └─────────────┘     └──────────────┘     └──────────────────┘
                                                                      │
                                                                      ▼
┌──────────────────┐     ┌──────────────────┐     ┌─────────────┐
│ Bước 5           │     │ Bước 6           │     │ Bước 7      │
│ Quyết định apply │     │ Theo dõi trạng   │     │ Bị reject / │
│ (chọn job)       │ ──→ │ thái (apply,     │ ──→ │ không phản  │
│                  │     │ pending, reject) │     │ hồi         │
│ Ai: Tôi          │     │ Ai: Tôi          │     │ Ai: Tôi     │
│ ⏱ 15 min         │     │ ⏱ 10 min         │     │ ⏱ N/A 🔴    │
│ In: đánh giá     │     │ In: job applied  │     │ In: result  │
│ Out: job apply   │     │ Out: tracking    │     │ Out: fail   │
└──────────────────┘     └──────────────────┘     └─────────────┘
                                                                      │
                                                                      ▼
┌──────────────────────────────────────────────┐
│ Bước 8                                       │
│ Tự đoán lý do fail + chỉnh CV + tìm job lại │
│                                              │
│ Ai: Tôi                                      │
│ ⏱ Không xác định 🔴                          │
│ In: CV + job cũ                              │
│ Out: CV mới (không chắc đúng)                │
└──────────────────────────────────────────────┘

🔴 = Bottleneck. Bottleneck lớn nhất:
Đọc & hiểu JD (Bước 3)
So sánh CV ↔ Job (Bước 4)
Không có feedback khi fail (Bước 7–8)
⏱ Tổng thời gian mỗi vòng apply: ~90–120 phút
```

### Ghi chú bottleneck
**Bước 3–4 (Đọc JD + So sánh với CV) chiếm ~50–60% tổng thời gian:**
 - Cần hiểu ngữ nghĩa (semantic)
 - Khó chuẩn hóa (mỗi JD viết khác nhau)
Dễ gây:
- Quá tải thông tin (10–20 job/lần)
- Đánh giá cảm tính, thiếu nhất quán
**Bước 8 (Phân tích lý do fail & cải thiện CV) là bottleneck lớn nhất:**
- Không có dữ liệu rõ ràng (thiếu feedback từ nhà tuyển dụng)
- Phụ thuộc hoàn toàn vào tự suy đoán
Dẫn đến:
- Không biết mình thiếu gì
- Cải thiện CV không đúng hướng
- Lặp lại cùng một sai lầm

---

## 4.2 — Problem Statement (6-field)

| Field                    | Nội dung                                                                          |
| ------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Actor / Operator**     | Người tìm việc (Junior/Fresher, ví dụ: tôi), đang apply nhiều job mỗi tuần nhưng thiếu feedback để cải thiện                                                                        |
| **Current Workflow**     | Tìm job → lọc → đọc JD → so sánh với CV → apply → chờ phản hồi → bị reject hoặc không phản hồi → tự đoán lý do → chỉnh CV → lặp lại. 7–8 bước, 90–120 phút/vòng, hoàn toàn thủ công |
| **Bottleneck**           | Không có feedback rõ ràng khi bị reject → phải tự suy đoán lý do fail và cách cải thiện CV. Quyết định mang tính cảm tính, không có hệ thống                                        |
| **Impact**               | Tốn ~6–10 giờ/tuần cho việc tìm và apply job. Tỷ lệ phản hồi thấp (~5%). Cải thiện CV không hiệu quả → kéo dài thời gian tìm việc                                                   |
| **Success Metric**       | Tăng tỷ lệ phản hồi (response rate) từ ~5% → 15–20%. Giảm thời gian phân tích & chỉnh CV. Có roadmap cải thiện rõ ràng sau mỗi vòng apply                                           |
| **Operational Boundary** | AI chỉ đóng vai trò assistant: phân tích CV ↔ JD và gợi ý cải thiện. Không tự động apply, không thay thế quyết định người dùng, không bịa yêu cầu hoặc skill                        |


### Sub-goals Decomposition

**TRƯỚC khi dùng AI**
- Thu thập dữ liệu:
  - CV hiện tại của người dùng
  - JD của các job đã apply / bị reject
- Chuẩn hóa dữ liệu:
  - Parse CV (skill, experience, project)
  - Extract thông tin từ JD (requirement, tech stack, level)
- Xây dựng format phân tích:
  - Template so sánh CV ↔ JD
  - Template gợi ý cải thiện (skill gap, wording, project)

**TRONG khi dùng AI**
- AI phân tích:
  - So sánh semantic giữa CV và JD
  - Xác định “gap” (thiếu skill, thiếu keyword, thiếu experience)
- AI gợi ý:
  - Cách cải thiện CV (viết lại bullet, thêm keyword)
  - Gợi ý skill cần học / project nên làm
- Người dùng:
  - Review gợi ý
  - Chọn giữ / sửa / bỏ
  - Update CV theo đề xuất phù hợp

### Metrics

| Loại              | Metric                                       | Ngưỡng                               |
| ----------------- | -------------------------------------------- | ------------------------------------ |
| **Efficiency**    | Thời gian phân tích & chỉnh CV mỗi tuần      | Giảm từ ~3–4 giờ → dưới 1 giờ        |
| **Effectiveness** | Tỷ lệ phản hồi (response rate)               | Tăng từ ~5% → 15–20%                 |
| **Quality**       | Mức độ phù hợp CV ↔ JD (fit score)           | Tăng theo thời gian (tracking trend) |
| **Learning**      | Số “gap” được xác định rõ sau mỗi vòng apply | 100% job có insight cụ thể           |
| **User Trust**    | Tỷ lệ user chấp nhận gợi ý AI                | > 60% suggestion được áp dụng        |

---

## 4.3 — Research

### Existing solution
**4.3.1 LinkedIn Jobs / TopCV / VietnamWorks**
- Mạnh:
  - Gợi ý job dựa trên profile
  - Có hệ thống recommendation cơ bản
- Yếu:
  - Không giải thích vì sao bạn phù hợp / không phù hợp
  - Không có feedback khi bị reject

**4.3.2 AI tools (ChatGPT, Gemini…)**
- Mạnh:
  - Có thể phân tích CV, viết lại nội dung
  - Gợi ý cải thiện
- Yếu:
  - Không có context lịch sử apply
  - Không có tracking → không tạo được feedback loop

### Case study
**AI Resume Optimization Tools (Jobscan, Rezi AI)**
- Dùng NLP để: So sánh CV với JD, Suggest keyword
Nhưng: Không biết kết quả apply → không cải thiện theo thời gian

**LinkedIn Job Recommendation System (Jobs)**
- Dùng ML để: Match job ↔ user profile, Ranking job theo relevance
Nhưng: Focus vào recommendation, không phải learning từ fail
### Quick poll
- 3/3 người tìm việc (bạn bè / cộng đồng) đều:
  - Apply nhiều job nhưng ít phản hồi
  - Không biết lý do bị reject
- 2 người có chỉnh CV nhiều lần. Nhưng không chắc chỉnh đúng hướng

---

## 4.4 — Future-State Flow + AI Fit

### AI Fit Check
Bài toán nằm ở:
**Complexity trung bình + Ambiguity cao → Phù hợp với LLM + reasoning**

### AI Suitability Check
Tick thiên về bên **phù hợp**:
 - Cần NLP + semantic understanding
 - Output dạng mở (insight, suggestion)
 - Không có công thức cố định → cần reasoning 

Bài toán phù hợp với AI nhưng có rủi ro cao:
- Không có label “lý do reject” thật
- Dễ hallucinate lý do không chính xác
- Gợi ý có thể:
- Chung chung
- Không actionable

Cách giảm rủi ro:
 - So sánh CV ↔ JD để suy ra gap (proxy feedback)
 - Dùng nhiều JD tương tự để tăng độ tin cậy
 - Giữ human-in-the-loop (user review)
 - Có thể hiển thị: “Confidence level” cho từng insight

### UX Check
Nếu AI phân tích sai hoặc không hữu ích:
 - Người dùng có thể:
    - Bỏ qua suggestion
    - Chọn lọc từng phần để áp dụng
    - So sánh nhiều suggestion khác nhau
  - Worst case:
Quay lại cách cũ (tự chỉnh CV)
- UX cần đảm bảo:
  - Không ép user tin AI
  - Hiển thị rõ:
    - Gap nào → từ đâu (JD nào)
  - Cho phép:
    - Edit trực tiếp CV dựa trên suggestion
## Future-State Flow

```text
┌─────────────┐     ┌──────────────────┐     ┌────────────────────────┐
│ Bước 1      │     │ Bước 2           │     │ Bước 3                │
│ 🔵 Auto-pull│ ──→ │ 🔵 AI phân tích │ ──→ │ 🔵 AI detect gap      │
│ CV + JD +   │     │ CV ↔ JD         │     │ (skill / keyword /    │
│ lịch sử apply│     │ (semantic)      │     │ experience thiếu)     │
└─────────────┘     └──────────────────┘     └────────────────────────┘
                                                      │
                                                      ▼
┌────────────────────────┐     ┌────────────────────────┐
│ Bước 4                 │     │ Bước 5                │
│ 🔵 AI gợi ý cải thiện │ ──→ │ 🟢 User review + edit │
│ - Sửa CV              │     │ - Chọn giữ / bỏ       │
│ - Thêm keyword        │     │ - Update CV           │
│ - Gợi ý skill         │     │ 🔴 Boundary:          │
│ - Roadmap học         │     │ User quyết định cuối  │
└────────────────────────┘     └────────────────────────┘
                                                      │
                                                      ▼
┌────────────────────────┐     ┌────────────────────────┐
│ Bước 6                 │     │ Bước 7                │
│ 🟢 Apply job           │ ──→ │ 🔵 Track result       │
│ (manual)               │     │ (response / reject)   │
└────────────────────────┘     └────────────────────────┘
                                                      │
                                                      ▼
┌──────────────────────────────────────────────┐
│ Bước 8                                       │
│ 🔵 AI học từ kết quả (feedback loop)         │
│ - Update đánh giá CV ↔ job                   │
│ - Cải thiện suggestion lần sau               │
└──────────────────────────────────────────────┘

➡️ Fallback: AI phân tích kém → Người dùng tự đánh giá lại
```

### AI Fit Decision
**Chốt: LLM + Reasoning**

**Vì sao không phải Agent**
1. workflow tuyến tính
2. Không cần tự động hành động
3. AI chỉ xử lý phần “thinking”

### Underspecification Check

| Điều chưa rõ                                        | Hậu quả                                    | Cách tìm ra                                |
| --------------------------------------------------- | ------------------------------------------ | ------------------------------------------ |
| “Gợi ý cải thiện tốt” nghĩa là gì?                  | Suggestion chung chung, user không dùng    | A/B test: đo tỷ lệ user áp dụng suggestion |
| Lý do reject có thể suy luận chính xác đến mức nào? | User hiểu sai vấn đề → cải thiện sai hướng | So sánh nhiều JD tương tự + user feedback  |
| User có thực sự tin AI không?                       | Không dùng system → fail adoption          | Track % suggestion được accept             |
| CV hiện tại có đủ thông tin để phân tích không?     | AI đưa ra insight sai / thiếu              | Kiểm tra CV sample, yêu cầu input chuẩn    |
| Có đủ dữ liệu lịch sử apply không?                  | Không tạo được feedback loop               | Cho phép user nhập thủ công lịch sử        |
